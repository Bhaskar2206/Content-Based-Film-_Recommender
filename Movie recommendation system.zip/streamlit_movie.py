#streamlit run "C:\Users\Tushar Lanjewar\Desktop\ML_Project\streamlit_movie.py"

import numpy as np
import pickle
import streamlit as st
import requests
import difflib

movies = pickle.load(open('C:/Users/Tushar Lanjewar/Desktop/ML_Project/movies.pkl', 'rb'))
similarity = pickle.load(open('C:/Users/Tushar Lanjewar/Desktop/ML_Project/similar.pkl', 'rb'))
movies_list=movies['title'].values

st.header("Movie Recommender System")
selectvalue=st.selectbox("Select movie from dropdown", movies_list)

def get_poster(movie_id):
     url = "https://api.themoviedb.org/3/movie/{}?api_key=41b1e164caa3b7774c8cc3b73c1a1fa4&language=en-US".format(movie_id)
     data=requests.get(url)
     data=data.json()
     poster_path = data['poster_path']
     full_path = "https://image.tmdb.org/t/p/w500/"+poster_path
     return full_path    




def recommend(movie):
  close_match = difflib.get_close_matches(movie, movies.title)[0]
  index = movies[movies.title == close_match].index[0]
  similarity_score = list(enumerate(similarity[index]))
  movie_suggest = sorted(similarity_score, key = lambda x:x[1], reverse = True)
  recommend_movie=[]
  recommend_poster=[]
  for i in movie_suggest[1:6]:
    movies_id=movies.iloc[i[0]].id
    recommend_movie.append(movies.iloc[i[0]].title)
    recommend_poster.append(get_poster(movies_id))
  return recommend_movie, recommend_poster    
    

if st.button("Show Recommend"):
    movie_name, movie_poster = recommend(selectvalue)
    col1,col2,col3,col4,col5=st.columns(5)
    with col1:
        st.text(movie_name[0])
        st.image(movie_poster[0])
    with col2:
        st.text(movie_name[1])
        st.image(movie_poster[1])
    with col3:
        st.text(movie_name[2])
        st.image(movie_poster[2])
    with col4:
        st.text(movie_name[3])
        st.image(movie_poster[3])
    with col5:
        st.text(movie_name[4])
        st.image(movie_poster[4])    